Feature: Login Functionality
  As a user of SauceDemo
  I want to be able to log in
  So that I can access the product catalog

  Background:
    Given user opens the browser
    And user navigates to the login page

  @smoke @sanity
  Scenario: Successful login with valid credentials
    When user enters username "standard_user" and password "secret_sauce"
    And user clicks the login button
    Then user should be redirected to the products page
    And page title should be "Products"

  @smoke @regression
  Scenario: Login fails with locked out user
    When user enters username "locked_out_user" and password "secret_sauce"
    And user clicks the login button
    Then error message "Epic sadface: Sorry, this user has been locked out." should be displayed

  @regression
  Scenario: Login fails with wrong password
    When user enters username "standard_user" and password "wrongpassword"
    And user clicks the login button
    Then error message "Epic sadface: Username and password do not match any user in this service" should be displayed

  @regression
  Scenario: Login fails with empty username
    When user leaves username empty and enters password "secret_sauce"
    And user clicks the login button
    Then error message "Epic sadface: Username is required" should be displayed

  @regression
  Scenario: Login fails with empty password
    When user enters username "standard_user" and leaves password empty
    And user clicks the login button
    Then error message "Epic sadface: Password is required" should be displayed

  @regression
  Scenario Outline: Login with multiple user types
    When user enters username "<username>" and password "<password>"
    And user clicks the login button
    Then login result should be "<result>"

    @smoke
    Examples: Valid Users
      | username           | password     | result   |
      | standard_user      | secret_sauce | success  |
      | problem_user       | secret_sauce | success  |
      | performance_glitch_user | secret_sauce | success |

    @regression
    Examples: Invalid Users
      | username      | password     | result  |
      | locked_out_user | secret_sauce | locked |
      | invalid_user  | wrongpass    | invalid |

  @regression
  Scenario: Login form fields using data table
    When user fills the login form with:
      | username | standard_user |
      | password | secret_sauce  |
    And user clicks the login button
    Then user should be redirected to the products page
