Feature: Products Page Functionality
  As a logged in user
  I want to browse and interact with products
  So that I can add them to my cart

  Background:
    Given user opens the browser
    And user is logged in as "standard_user" with password "secret_sauce"

  @smoke @sanity
  Scenario: Products page loads successfully
    Then user should be on the products page
    And product list should be displayed

  @smoke
  Scenario: Add a single product to cart
    When user adds "Sauce Labs Backpack" to the cart
    Then cart count should be "1"

  @smoke
  Scenario: Remove a product from cart
    When user adds "Sauce Labs Backpack" to the cart
    And user removes "Sauce Labs Backpack" from the cart
    Then cart count should be "0"

  @regression
  Scenario: Add multiple products to cart
    When user adds the following products to the cart:
      | Sauce Labs Backpack        |
      | Sauce Labs Bike Light      |
      | Sauce Labs Bolt T-Shirt    |
    Then cart count should be "3"

  @regression
  Scenario: Sort products by price low to high
    When user sorts products by "Price (low to high)"
    Then first product price should be lowest

  @regression
  Scenario: Sort products by name A to Z
    When user sorts products by "Name (A to Z)"
    Then products should be sorted alphabetically

  @sanity
  Scenario: Navigate to cart from products page
    When user adds "Sauce Labs Backpack" to the cart
    And user clicks on the cart icon
    Then user should be on the cart page
