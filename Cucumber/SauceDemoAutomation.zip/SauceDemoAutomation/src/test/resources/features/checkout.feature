Feature: Checkout Functionality
  As a logged in user
  I want to checkout my cart
  So that I can complete my purchase

  Background:
    Given user opens the browser
    And user is logged in as "standard_user" with password "secret_sauce"
    And user adds "Sauce Labs Backpack" to the cart
    And user clicks on the cart icon

  @smoke @sanity
  Scenario: Complete a successful checkout
    When user clicks checkout
    And user fills checkout details with:
      | firstName | John     |
      | lastName  | Doe      |
      | zipCode   | 600001   |
    And user clicks continue
    And user clicks finish
    Then order confirmation message should be displayed

  @regression
  Scenario: Checkout fails with empty first name
    When user clicks checkout
    And user fills checkout details with:
      | firstName |          |
      | lastName  | Doe      |
      | zipCode   | 600001   |
    And user clicks continue
    Then checkout error "Error: First Name is required" should be displayed

  @regression
  Scenario: Checkout fails with empty last name
    When user clicks checkout
    And user fills checkout details with:
      | firstName | John     |
      | lastName  |          |
      | zipCode   | 600001   |
    And user clicks continue
    Then checkout error "Error: Last Name is required" should be displayed

  @regression
  Scenario: Checkout fails with empty zip code
    When user clicks checkout
    And user fills checkout details with:
      | firstName | John     |
      | lastName  | Doe      |
      | zipCode   |          |
    And user clicks continue
    Then checkout error "Error: Postal Code is required" should be displayed

  @smoke
  Scenario: Verify order summary before finishing
    When user clicks checkout
    And user fills checkout details with:
      | firstName | Jane     |
      | lastName  | Smith    |
      | zipCode   | 400001   |
    And user clicks continue
    Then order summary should show item "Sauce Labs Backpack"
    And order total should be displayed
