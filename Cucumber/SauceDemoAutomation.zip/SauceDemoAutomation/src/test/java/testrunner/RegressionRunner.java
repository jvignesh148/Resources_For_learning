package testrunner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

/**
 * Regression Runner — runs all @regression scenarios
 * Full regression suite for complete coverage
 * Run: mvn test -Dbrowser=firefox
 */
@RunWith(Cucumber.class)
@CucumberOptions(
        features   = "src/test/resources/features",
        glue       = {"stepdefinitions", "hooks"},
        plugin     = {
                "pretty",
                "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
        },
        tags       = "@regression",
        monochrome = true
)
public class RegressionRunner {

}
