package testrunner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

/**
 * Sanity Runner — runs all @sanity scenarios
 * Basic checks after deployment or build
 * Run: mvn test -Dbrowser=edge
 */
@RunWith(Cucumber.class)
@CucumberOptions(
        features   = "src/test/resources/features",
        glue       = {"stepdefinitions", "hooks"},
        plugin     = {
                "pretty",
                "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
        },
        tags       = "@sanity",
        monochrome = true
)
public class SanityRunner {

}
