package testrunner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

/**
 * Smoke Runner — runs all @smoke scenarios
 * Quick sanity check to verify critical paths work
 * Run: mvn test -Dbrowser=chrome
 */
@RunWith(Cucumber.class)
@CucumberOptions(
        features   = "src/test/resources/features",
        glue       = {"stepdefinitions", "hooks"},
        plugin     = {
                "pretty",
                "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
        },
        tags       = "@smoke",
        monochrome = true
)
public class SmokeRunner {

}
