package stepdefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import utils.ConfigReader;
import java.time.Duration;

public class DriverManager {

    // ThreadLocal ensures each parallel thread gets its own WebDriver instance
    private static ThreadLocal<WebDriver> driver = new ThreadLocal<>();

    public static void initDriver() {
        // Runtime -Dbrowser param takes priority over config.properties
        String browser = System.getProperty("browser", ConfigReader.getBrowser());

        WebDriver webDriver;

        switch (browser.toLowerCase().trim()) {

            case "firefox" -> {
                FirefoxOptions options = new FirefoxOptions();
                options.addArguments("--start-maximized");
                webDriver = new FirefoxDriver(options);
            }

            case "edge" -> {
                EdgeOptions options = new EdgeOptions();
                options.addArguments("--start-maximized");
                webDriver = new EdgeDriver(options);
            }

            case "chrome-headless" -> {
                // Used in CI/CD pipelines — no browser UI
                ChromeOptions options = new ChromeOptions();
                options.addArguments("--headless");
                options.addArguments("--window-size=1920,1080");
                options.addArguments("--disable-gpu");
                options.addArguments("--no-sandbox");
                webDriver = new ChromeDriver(options);
            }

            default -> {
                ChromeOptions options = new ChromeOptions();
                options.addArguments("--start-maximized");
                webDriver = new ChromeDriver(options);
            }
        }

        webDriver.manage().timeouts()
                 .implicitlyWait(Duration.ofSeconds(ConfigReader.getImplicitWait()));

        // Assign driver to THIS thread only
        driver.set(webDriver);
    }

    // Returns driver for THIS thread only
    public static WebDriver getDriver() {
        return driver.get();
    }

    // Quit and clean up driver for THIS thread
    public static void quitDriver() {
        if (driver.get() != null) {
            driver.get().quit();
            driver.remove(); // Prevents memory leaks in parallel runs
        }
    }
}
