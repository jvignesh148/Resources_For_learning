package stepdefinitions;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;
import org.junit.Assert;
import pageobjects.*;
import utils.ConfigReader;

import java.util.List;
import java.util.Map;

public class StepDefinitions {

    // Page objects — created fresh per scenario via Hooks
    LoginPage    loginPage;
    ProductsPage productsPage;
    CartPage     cartPage;
    CheckoutPage checkoutPage;

    // ── Common Steps ──────────────────────────────────────────────────────

    @Given("user opens the browser")
    public void user_opens_browser() {
        DriverManager.initDriver();
    }

    @Given("user navigates to the login page")
    public void user_navigates_to_login_page() {
        DriverManager.getDriver().get(ConfigReader.getUrl());
        loginPage = new LoginPage();
    }

    // ── Login Steps ───────────────────────────────────────────────────────

    @When("user enters username {string} and password {string}")
    public void user_enters_username_and_password(String username, String password) {
        loginPage = new LoginPage();
        loginPage.enterUsername(username);
        loginPage.enterPassword(password);
    }

    @When("user leaves username empty and enters password {string}")
    public void user_leaves_username_empty(String password) {
        loginPage = new LoginPage();
        loginPage.enterPassword(password);
    }

    @When("user enters username {string} and leaves password empty")
    public void user_leaves_password_empty(String username) {
        loginPage = new LoginPage();
        loginPage.enterUsername(username);
    }

    @When("user clicks the login button")
    public void user_clicks_login_button() {
        loginPage.clickLoginButton();
    }

    @When("user fills the login form with:")
    public void user_fills_login_form(DataTable dataTable) {
        // DataTable as key-value map (no header row)
        Map<String, String> credentials = dataTable.asMap();
        loginPage = new LoginPage();
        loginPage.loginWith(
            credentials.get("username"),
            credentials.get("password")
        );
    }

    @Then("user should be redirected to the products page")
    public void user_redirected_to_products_page() {
        productsPage = new ProductsPage();
        Assert.assertTrue(
            "User was NOT redirected to products page",
            productsPage.isOnProductsPage()
        );
    }

    @Then("page title should be {string}")
    public void page_title_should_be(String expectedTitle) {
        productsPage = new ProductsPage();
        Assert.assertEquals(
            "Page title mismatch",
            expectedTitle,
            productsPage.getPageTitle()
        );
    }

    @Then("error message {string} should be displayed")
    public void error_message_should_be_displayed(String expectedMsg) {
        Assert.assertTrue("Error message not displayed", loginPage.isErrorDisplayed());
        Assert.assertEquals("Error message mismatch", expectedMsg, loginPage.getErrorMessage());
    }

    @Then("login result should be {string}")
    public void login_result_should_be(String result) {
        productsPage = new ProductsPage();
        switch (result) {
            case "success" -> Assert.assertTrue(
                "Expected success but login failed",
                productsPage.isOnProductsPage()
            );
            case "locked" -> {
                Assert.assertTrue("Expected locked error", loginPage.isErrorDisplayed());
                Assert.assertTrue(
                    "Expected locked out message",
                    loginPage.getErrorMessage().contains("locked out")
                );
            }
            case "invalid" -> {
                Assert.assertTrue("Expected invalid error", loginPage.isErrorDisplayed());
                Assert.assertTrue(
                    "Expected invalid credentials message",
                    loginPage.getErrorMessage().contains("do not match")
                );
            }
        }
    }

    // ── Products Steps ────────────────────────────────────────────────────

    @Given("user is logged in as {string} with password {string}")
    public void user_is_logged_in(String username, String password) {
        DriverManager.getDriver().get(ConfigReader.getUrl());
        loginPage = new LoginPage();
        loginPage.loginWith(username, password);
        productsPage = new ProductsPage();
    }

    @Then("user should be on the products page")
    public void user_should_be_on_products_page() {
        productsPage = new ProductsPage();
        Assert.assertTrue("Not on products page", productsPage.isOnProductsPage());
    }

    @Then("product list should be displayed")
    public void product_list_should_be_displayed() {
        Assert.assertTrue("Product list not visible", productsPage.isProductListDisplayed());
    }

    @When("user adds {string} to the cart")
    public void user_adds_product_to_cart(String productName) {
        productsPage = new ProductsPage();
        productsPage.addToCart(productName);
    }

    @When("user removes {string} from the cart")
    public void user_removes_product_from_cart(String productName) {
        productsPage = new ProductsPage();
        productsPage.removeFromCart(productName);
    }

    @Then("cart count should be {string}")
    public void cart_count_should_be(String expectedCount) {
        productsPage = new ProductsPage();
        if (expectedCount.equals("0")) {
            Assert.assertFalse(
                "Cart badge still visible when it should be empty",
                productsPage.getCartCount().equals("1")
            );
        } else {
            Assert.assertEquals(
                "Cart count mismatch",
                expectedCount,
                productsPage.getCartCount()
            );
        }
    }

    @When("user adds the following products to the cart:")
    public void user_adds_multiple_products(DataTable dataTable) {
        // DataTable as single-column list
        List<String> products = dataTable.asList();
        productsPage = new ProductsPage();
        for (String product : products) {
            productsPage.addToCart(product);
        }
    }

    @When("user sorts products by {string}")
    public void user_sorts_products_by(String sortOption) {
        productsPage = new ProductsPage();
        productsPage.sortBy(sortOption);
    }

    @Then("first product price should be lowest")
    public void first_product_price_should_be_lowest() {
        productsPage = new ProductsPage();
        List<Double> prices = productsPage.getProductPrices();
        double firstPrice = prices.get(0);
        double minPrice = prices.stream().mapToDouble(Double::doubleValue).min().orElse(0);
        Assert.assertEquals("First price is not the lowest", minPrice, firstPrice, 0.01);
    }

    @Then("products should be sorted alphabetically")
    public void products_should_be_sorted_alphabetically() {
        productsPage = new ProductsPage();
        List<String> names = productsPage.getProductNames();
        List<String> sorted = names.stream().sorted().toList();
        Assert.assertEquals("Products not sorted alphabetically", sorted, names);
    }

    @When("user clicks on the cart icon")
    public void user_clicks_cart_icon() {
        productsPage = new ProductsPage();
        productsPage.clickCartIcon();
        cartPage = new CartPage();
    }

    @Then("user should be on the cart page")
    public void user_should_be_on_cart_page() {
        cartPage = new CartPage();
        Assert.assertTrue("Not on cart page", cartPage.isOnCartPage());
    }

    // ── Checkout Steps ────────────────────────────────────────────────────

    @When("user clicks checkout")
    public void user_clicks_checkout() {
        cartPage = new CartPage();
        cartPage.clickCheckout();
        checkoutPage = new CheckoutPage();
    }

    @When("user fills checkout details with:")
    public void user_fills_checkout_details(DataTable dataTable) {
        // DataTable as key-value map
        Map<String, String> details = dataTable.asMap();
        checkoutPage = new CheckoutPage();
        checkoutPage.fillCheckoutDetails(
            details.get("firstName"),
            details.get("lastName"),
            details.get("zipCode")
        );
    }

    @When("user clicks continue")
    public void user_clicks_continue() {
        checkoutPage = new CheckoutPage();
        checkoutPage.clickContinue();
    }

    @When("user clicks finish")
    public void user_clicks_finish() {
        checkoutPage = new CheckoutPage();
        checkoutPage.clickFinish();
    }

    @Then("order confirmation message should be displayed")
    public void order_confirmation_should_be_displayed() {
        checkoutPage = new CheckoutPage();
        Assert.assertTrue("Order confirmation not displayed", checkoutPage.isOrderConfirmed());
        Assert.assertEquals(
            "Confirmation message mismatch",
            "Thank you for your order!",
            checkoutPage.getConfirmationMessage()
        );
    }

    @Then("checkout error {string} should be displayed")
    public void checkout_error_should_be_displayed(String expectedError) {
        checkoutPage = new CheckoutPage();
        Assert.assertTrue("Checkout error not displayed", checkoutPage.isErrorDisplayed());
        Assert.assertEquals("Checkout error mismatch", expectedError, checkoutPage.getErrorMessage());
    }

    @Then("order summary should show item {string}")
    public void order_summary_should_show_item(String productName) {
        checkoutPage = new CheckoutPage();
        Assert.assertTrue(
            "Product not found in order summary: " + productName,
            checkoutPage.isSummaryItemDisplayed(productName)
        );
    }

    @Then("order total should be displayed")
    public void order_total_should_be_displayed() {
        checkoutPage = new CheckoutPage();
        String total = checkoutPage.getOrderTotal();
        Assert.assertNotNull("Order total not displayed", total);
        Assert.assertTrue("Order total is empty", !total.isEmpty());
    }
}
