package utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ConfigReader {

    private static Properties properties;

    // Loads config.properties once when class is first used
    static {
        try {
            FileInputStream file = new FileInputStream(
                "src/test/resources/config.properties"
            );
            properties = new Properties();
            properties.load(file);
            file.close();
        } catch (IOException e) {
            throw new RuntimeException(
                "config.properties not found! " + e.getMessage()
            );
        }
    }

    public static String getUrl() {
        return properties.getProperty("url");
    }

    public static String getBrowser() {
        return properties.getProperty("browser");
    }

    public static String getUsername() {
        return properties.getProperty("username");
    }

    public static String getPassword() {
        return properties.getProperty("password");
    }

    public static String getLockedUsername() {
        return properties.getProperty("lockedUsername");
    }

    public static String getProblemUsername() {
        return properties.getProperty("problemUsername");
    }

    public static int getImplicitWait() {
        return Integer.parseInt(properties.getProperty("implicitWait"));
    }

    public static int getExplicitWait() {
        return Integer.parseInt(properties.getProperty("explicitWait"));
    }

    public static String getEnv() {
        return properties.getProperty("env");
    }

    // Generic getter for any key
    public static String get(String key) {
        return properties.getProperty(key);
    }
}
