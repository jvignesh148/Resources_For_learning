package hooks;

import io.cucumber.java.*;
import org.openqa.selenium.*;
import stepdefinitions.DriverManager;
import utils.ConfigReader;

public class Hooks {

    // ── Runs before EVERY scenario ────────────────────────────────────────
    @Before
    public void setUp(Scenario scenario) {
        String browser = System.getProperty("browser", ConfigReader.getBrowser());
        System.out.println("\n========================================");
        System.out.println("Starting : " + scenario.getName());
        System.out.println("Tags     : " + scenario.getSourceTagNames());
        System.out.println("Browser  : " + browser);
        System.out.println("========================================");
    }

    // ── Runs after EVERY scenario ─────────────────────────────────────────
    @After
    public void tearDown(Scenario scenario) {
        WebDriver driver = DriverManager.getDriver();

        // Attach screenshot to report if scenario failed
        if (scenario.isFailed() && driver != null) {
            byte[] screenshot = ((TakesScreenshot) driver)
                    .getScreenshotAs(OutputType.BYTES);
            scenario.attach(
                screenshot,
                "image/png",
                "Failed: " + scenario.getName()
            );
            System.out.println("Screenshot captured for failed scenario: " + scenario.getName());
        }

        // Print result
        System.out.println("Result   : " + scenario.getStatus());
        System.out.println("========================================\n");

        // Quit driver — ThreadLocal removes it cleanly for parallel runs
        DriverManager.quitDriver();
    }

    // ── Runs before @smoke scenarios only ─────────────────────────────────
    @Before("@smoke")
    public void beforeSmoke() {
        System.out.println("[SMOKE] Setting up smoke test environment");
    }

    // ── Runs before @regression scenarios only ────────────────────────────
    @Before("@regression")
    public void beforeRegression() {
        System.out.println("[REGRESSION] Setting up regression test environment");
    }
}
