package pageobjects;

import org.openqa.selenium.*;
import java.util.List;
import java.util.stream.Collectors;

public class ProductsPage extends BasePage {

    // ── Locators ──────────────────────────────────────────────────────────
    private final By pageTitle       = By.cssSelector(".title");
    private final By productList     = By.cssSelector(".inventory_item");
    private final By cartIcon        = By.cssSelector(".shopping_cart_link");
    private final By cartCount       = By.cssSelector(".shopping_cart_badge");
    private final By sortDropdown    = By.cssSelector("[data-test='product_sort_container']");
    private final By productPrices   = By.cssSelector(".inventory_item_price");
    private final By productNames    = By.cssSelector(".inventory_item_name");

    // Dynamic locator — Add to cart button for a specific product
    private By addToCartButton(String productName) {
        String id = productName.toLowerCase()
                               .replace(" ", "-")
                               .replace("(", "")
                               .replace(")", "");
        return By.cssSelector("[data-test='add-to-cart-" + id + "']");
    }

    // Dynamic locator — Remove button for a specific product
    private By removeButton(String productName) {
        String id = productName.toLowerCase()
                               .replace(" ", "-")
                               .replace("(", "")
                               .replace(")", "");
        return By.cssSelector("[data-test='remove-" + id + "']");
    }

    // ── Actions ───────────────────────────────────────────────────────────
    public void addToCart(String productName) {
        click(addToCartButton(productName));
    }

    public void removeFromCart(String productName) {
        click(removeButton(productName));
    }

    public void clickCartIcon() {
        click(cartIcon);
    }

    public void sortBy(String sortOption) {
        selectByText(sortDropdown, sortOption);
    }

    // ── Getters ───────────────────────────────────────────────────────────
    public String getPageTitle() {
        return getText(pageTitle);
    }

    public boolean isProductListDisplayed() {
        return isDisplayed(productList);
    }

    public String getCartCount() {
        try {
            return getText(cartCount);
        } catch (Exception e) {
            return "0"; // No badge means empty cart
        }
    }

    public boolean isOnProductsPage() {
        return getCurrentUrl().contains("inventory");
    }

    public List<Double> getProductPrices() {
        return driver.findElements(productPrices)
                     .stream()
                     .map(e -> Double.parseDouble(e.getText().replace("$", "")))
                     .collect(Collectors.toList());
    }

    public List<String> getProductNames() {
        return driver.findElements(productNames)
                     .stream()
                     .map(WebElement::getText)
                     .collect(Collectors.toList());
    }
}
