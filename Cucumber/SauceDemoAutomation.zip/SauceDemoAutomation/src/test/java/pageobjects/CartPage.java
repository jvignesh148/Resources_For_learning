package pageobjects;

import org.openqa.selenium.By;

public class CartPage extends BasePage {

    // ── Locators ──────────────────────────────────────────────────────────
    private final By checkoutButton  = By.cssSelector("[data-test='checkout']");
    private final By cartItems       = By.cssSelector(".cart_item");
    private final By continueShoppingButton = By.cssSelector("[data-test='continue-shopping']");

    // Dynamic — check if specific item is in cart
    private By cartItemName(String productName) {
        return By.xpath("//div[@class='inventory_item_name'][text()='" + productName + "']");
    }

    // ── Actions ───────────────────────────────────────────────────────────
    public void clickCheckout() {
        click(checkoutButton);
    }

    public void clickContinueShopping() {
        click(continueShoppingButton);
    }

    // ── Getters ───────────────────────────────────────────────────────────
    public boolean isOnCartPage() {
        return getCurrentUrl().contains("cart");
    }

    public boolean isItemInCart(String productName) {
        return isDisplayed(cartItemName(productName));
    }

    public int getCartItemCount() {
        return driver.findElements(cartItems).size();
    }
}
