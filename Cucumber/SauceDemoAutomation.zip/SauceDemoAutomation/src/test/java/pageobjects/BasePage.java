package pageobjects;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import stepdefinitions.DriverManager;
import utils.ConfigReader;
import java.time.Duration;

public class BasePage {

    protected WebDriver driver;
    protected WebDriverWait wait;

    public BasePage() {
        this.driver = DriverManager.getDriver();
        this.wait   = new WebDriverWait(
            driver,
            Duration.ofSeconds(ConfigReader.getExplicitWait())
        );
    }

    // Wait for element to be clickable then click
    protected void click(By locator) {
        wait.until(ExpectedConditions.elementToBeClickable(locator)).click();
    }

    // Wait for element to be visible then clear and type
    protected void type(By locator, String text) {
        WebElement element = wait.until(
            ExpectedConditions.visibilityOfElementLocated(locator)
        );
        element.clear();
        if (text != null && !text.isEmpty()) {
            element.sendKeys(text);
        }
    }

    // Wait for element then get its text
    protected String getText(By locator) {
        return wait.until(
            ExpectedConditions.visibilityOfElementLocated(locator)
        ).getText();
    }

    // Check if element is present and displayed
    protected boolean isDisplayed(By locator) {
        try {
            return driver.findElement(locator).isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    // Select from dropdown by visible text
    protected void selectByText(By locator, String text) {
        WebElement dropdown = wait.until(
            ExpectedConditions.visibilityOfElementLocated(locator)
        );
        new Select(dropdown).selectByVisibleText(text);
    }

    // Get current page URL
    protected String getCurrentUrl() {
        return driver.getCurrentUrl();
    }

    // Get page title
    protected String getPageTitle() {
        return driver.getTitle();
    }

    // Wait for URL to contain text
    protected void waitForUrl(String urlFragment) {
        wait.until(ExpectedConditions.urlContains(urlFragment));
    }
}
