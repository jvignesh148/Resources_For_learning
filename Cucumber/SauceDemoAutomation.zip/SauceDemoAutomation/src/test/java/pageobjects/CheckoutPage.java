package pageobjects;

import org.openqa.selenium.By;

public class CheckoutPage extends BasePage {

    // ── Locators ──────────────────────────────────────────────────────────
    private final By firstNameField   = By.id("first-name");
    private final By lastNameField    = By.id("last-name");
    private final By zipCodeField     = By.id("postal-code");
    private final By continueButton   = By.cssSelector("[data-test='continue']");
    private final By finishButton     = By.cssSelector("[data-test='finish']");
    private final By errorMessage     = By.cssSelector("[data-test='error']");
    private final By confirmationMsg  = By.cssSelector(".complete-header");
    private final By orderTotal       = By.cssSelector(".summary_total_label");
    private final By summaryItemNames = By.cssSelector(".inventory_item_name");

    // ── Actions ───────────────────────────────────────────────────────────
    public void enterFirstName(String firstName) {
        type(firstNameField, firstName);
    }

    public void enterLastName(String lastName) {
        type(lastNameField, lastName);
    }

    public void enterZipCode(String zipCode) {
        type(zipCodeField, zipCode);
    }

    public void fillCheckoutDetails(String firstName, String lastName, String zipCode) {
        enterFirstName(firstName);
        enterLastName(lastName);
        enterZipCode(zipCode);
    }

    public void clickContinue() {
        click(continueButton);
    }

    public void clickFinish() {
        click(finishButton);
    }

    // ── Getters ───────────────────────────────────────────────────────────
    public String getErrorMessage() {
        return getText(errorMessage);
    }

    public boolean isErrorDisplayed() {
        return isDisplayed(errorMessage);
    }

    public String getConfirmationMessage() {
        return getText(confirmationMsg);
    }

    public boolean isOrderConfirmed() {
        return isDisplayed(confirmationMsg);
    }

    public String getOrderTotal() {
        return getText(orderTotal);
    }

    public boolean isSummaryItemDisplayed(String productName) {
        return driver.findElements(summaryItemNames)
                     .stream()
                     .anyMatch(e -> e.getText().equals(productName));
    }

    public boolean isOnCheckoutPage() {
        return getCurrentUrl().contains("checkout");
    }
}
