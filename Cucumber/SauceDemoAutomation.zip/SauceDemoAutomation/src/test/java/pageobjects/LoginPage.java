package pageobjects;

import org.openqa.selenium.By;

public class LoginPage extends BasePage {

    // ── Locators ──────────────────────────────────────────────────────────
    private final By usernameField  = By.id("user-name");
    private final By passwordField  = By.id("password");
    private final By loginButton    = By.id("login-button");
    private final By errorMessage   = By.cssSelector("[data-test='error']");

    // ── Actions ───────────────────────────────────────────────────────────
    public void enterUsername(String username) {
        type(usernameField, username);
    }

    public void enterPassword(String password) {
        type(passwordField, password);
    }

    public void clickLoginButton() {
        click(loginButton);
    }

    // Combined login action
    public void loginWith(String username, String password) {
        enterUsername(username);
        enterPassword(password);
        clickLoginButton();
    }

    // ── Getters ───────────────────────────────────────────────────────────
    public String getErrorMessage() {
        return getText(errorMessage);
    }

    public boolean isErrorDisplayed() {
        return isDisplayed(errorMessage);
    }

    public boolean isOnLoginPage() {
        return getCurrentUrl().equals("https://www.saucedemo.com/");
    }
}
