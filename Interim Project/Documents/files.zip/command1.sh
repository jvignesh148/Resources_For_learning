#!/bin/bash

# 1) Initialize git
git init

# 2) Add ONLY Employee.java and Driver.java to git
git add Employee.java Driver.java

# 3) Commit these 2 files using the comment "Initial commit Employee and Driver.java"
git commit -m "Initial commit Employee and Driver.java"
