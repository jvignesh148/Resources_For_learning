#!/bin/bash

# 4) Create a branch named "DEV_feature"
git branch DEV_feature

# 5) Switch to this new branch using checkout
git checkout DEV_feature

# 6) Add the below code to Employee.java
cat > Employee.java << 'JAVA'
public class Employee {
    String name;
    int id;
    String designation;
    double salary;
    long phoneNo;
}
JAVA

# 7) Add Employee.java to Git
git add Employee.java

# 8) Commit Employee.java using the comment "Employee with additional attributes"
git commit -m "Employee with additional attributes"

# 9) Create a tag named projectv1.1 with the tag message "Project Starter Code"
git tag -a projectv1.1 -m "Project Starter Code"

# 10) Create EmployeeUtil.java and add the required code
cat > EmployeeUtil.java << 'JAVA'
public class EmployeeUtil {
    public void sortEmployee(List<Employee> empList){
    }
}
JAVA

# 11) Add EmployeeUtil.java ONLY to Git
git add EmployeeUtil.java

# 12) Commit the file EmployeeUtil.java using the comment "Added EmployeeUtil"
git commit -m "Added EmployeeUtil"

# 13) Create a tag named projectv1.2 with the tag message "Project With EmployeeUtil"
git tag -a projectv1.2 -m "Project With EmployeeUtil"
