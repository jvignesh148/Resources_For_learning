package org.example.Tests.AdminTest;

import org.example.Pages.AdminPages.AdminHomePage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class AdminHomePageTest extends AdminBaseTest {
    AdminHomePage page;

    @BeforeMethod
    public void navigator() {
        driver.navigate().refresh();
    }

    @DataProvider(name = "flightData")
    public Object[][] flightData() {
        return new Object[][] {
                { "DA 007", "Deccan Airlines", "MAA — Chennai", "BOM — Mumbai", "06/01/2026", "17:20", "06/02/2026", "15:15", "180", "20", "5000" },
        };
    }

    @Test(priority = 1, dataProvider = "flightData")
    public void createFlightpageTest (String flightCode, String airlineName, String origin, String destination, String departureDate, String departureTime, String arrivalDate, String arrivalTime, String totalSeats, String tatkalSeats, String baseFare){
        page = new AdminHomePage(driver);
        page.clickSubmitButton();
        page.enterFlightCode(flightCode);
        page.enterAirlineName(airlineName);
        page.selectOrigin(origin);
        page.selectDestination(destination);

        page.enterDepartureDate(departureDate);
        page.enterDepartureTime(departureTime);

        page.enterArrivalDate(arrivalDate);
        page.enterArrivalTime(arrivalTime);

        page.enterTotalSeats(totalSeats);
        page.enterTatkalSeats(tatkalSeats);
        page.enterBaseFare(baseFare);

        page.clickCreateFlight();

    }

    @Test
    public void createFlightWithAllEmptyFields() {
        page = new AdminHomePage(driver);
        page.clickSubmitButton();
        page.clickCreateFlight();
        Assert.assertTrue(page.isFormStillOpen(),
                "Form should not submit with empty fields");
    }

    @Test
    public void createFlightWhereArrivalBeforeDeparture() {
        page = new AdminHomePage(driver);
        page.clickSubmitButton();
        page.enterFlightCode("DA 999");
        page.enterAirlineName("Deccan Airlines");
        page.selectOrigin("MAA — Chennai");
        page.selectDestination("BOM — Mumbai");
        page.enterDepartureDate("06/10/2026");
        page.enterDepartureTime("17:20");
        page.enterArrivalDate("06/09/2026");
        page.enterArrivalTime("15:15");
        page.enterTotalSeats("180");
        page.enterTatkalSeats("20");
        page.enterBaseFare("5000");
        page.clickCreateFlight();
        Assert.assertTrue(page.isErrorShown(),
                "Arrival before departure should show error");
    }

    @Test
    public void createFlightWhereTatkalExceedsTotalSeats() {
        page = new AdminHomePage(driver);
        page.clickSubmitButton();
        page.enterFlightCode("DA 998");
        page.enterAirlineName("Deccan Airlines");
        page.selectOrigin("MAA — Chennai");
        page.selectDestination("BOM — Mumbai");
        page.enterDepartureDate("06/10/2026");
        page.enterDepartureTime("17:20");
        page.enterArrivalDate("06/11/2026");
        page.enterArrivalTime("15:15");
        page.enterTotalSeats("50");
        page.enterTatkalSeats("100");
        page.enterBaseFare("5000");
        page.clickCreateFlight();
        Assert.assertTrue(page.isErrorShown(),
                "Tatkal seats exceeding total seats should show error");
    }

    @Test
    public void createFlightWithZeroSeats() {
        page = new AdminHomePage(driver);
        page.clickSubmitButton();
        page.enterFlightCode("DA 997");
        page.enterAirlineName("Deccan Airlines");
        page.selectOrigin("MAA — Chennai");
        page.selectDestination("BOM — Mumbai");
        page.enterDepartureDate("06/10/2026");
        page.enterDepartureTime("17:20");
        page.enterArrivalDate("06/11/2026");
        page.enterArrivalTime("15:15");
        page.enterTotalSeats("0");
        page.enterTatkalSeats("0");
        page.enterBaseFare("5000");
        page.clickCreateFlight();
        Assert.assertTrue(page.isErrorShown(),
                "Zero seats should show error");
    }

    @Test
    public void createFlightWithNegativeFare() {
        page = new AdminHomePage(driver);
        page.clickSubmitButton();
        page.enterFlightCode("DA 996");
        page.enterAirlineName("Deccan Airlines");
        page.selectOrigin("MAA — Chennai");
        page.selectDestination("BOM — Mumbai");
        page.enterDepartureDate("06/10/2026");
        page.enterDepartureTime("17:20");
        page.enterArrivalDate("06/11/2026");
        page.enterArrivalTime("15:15");
        page.enterTotalSeats("180");
        page.enterTatkalSeats("20");
        page.enterBaseFare("-500");
        page.clickCreateFlight();
        Assert.assertTrue(page.isErrorShown(),
                "Negative fare should show error");
    }

    @Test
    public void createFlightWithSameOriginAndDestination() {
        page = new AdminHomePage(driver);
        page.clickSubmitButton();
        page.enterFlightCode("DA 995");
        page.enterAirlineName("Deccan Airlines");
        page.selectOrigin("MAA — Chennai");
        page.selectDestination("MAA — Chennai");
        page.enterDepartureDate("06/10/2026");
        page.enterDepartureTime("17:20");
        page.enterArrivalDate("06/11/2026");
        page.enterArrivalTime("15:15");
        page.enterTotalSeats("180");
        page.enterTatkalSeats("20");
        page.enterBaseFare("5000");
        page.clickCreateFlight();
        Assert.assertTrue(page.isErrorShown(),
                "Same origin and destination should show error");
    }

}



