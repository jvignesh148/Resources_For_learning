package org.example.Tests.UserTest;

import org.example.Listeners.TestListener;
import org.example.Pages.UserPages.GuestDetailsPage;
import org.example.Pages.UserPages.HomePage;
import org.example.Pages.UserPages.LoginPage;
import org.example.Pages.UserPages.PlaneSelectionPage;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

@Listeners(TestListener.class)
public class HomePageTest extends UserBaseTest {

    @BeforeClass
    public void setUp() {
        openBrowser();
        login();
    }

    @BeforeMethod
    public void goToHome() {
        driver.get("http://localhost:4200/home");
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.urlContains("/home"));
    }

    @AfterClass
    public void tearDown() {
        closeBrowser();
    }

    HomePage home;
    PlaneSelectionPage planeSelectionPage;
    GuestDetailsPage guestDetailsPage;

    //-----------------------------------------------------------------------------------
    //                                  Data Provider
    //-----------------------------------------------------------------------------------
    @DataProvider
    public Object[][] dataMethod(){
        return new Object[][]{
                {
                        "vignesh@gmail.com",
                        "Vignesh@1234"
                }
        };
    }

    @DataProvider
    public Object[][] homeDataMethod(){
        return new Object[][]{
                {
                        "PREMIUM_ECONOMY",
                        "COK",
                        "BLR",
                        "05-06-2026"
                }
        };
    }

    @DataProvider
    public Object[][] guestDataMethod() {
        return new Object[][]{
                {"Virat", "Kohli", "38", "MALE", "9788376597"}
        };
    }

    @Test(dataProvider = "homeDataMethod", priority = 1)
    public void validation(String drop , String from , String to , String date){
        home = new HomePage(driver);
        home.setDrop(drop);
        home.setFrom(from);
        home.setTo(to);
        home.setDate(date);
        home.clickButton();
    }

//    @Test(priority = 2, dataProvider = "homeDataMethod")
//    public void planeSelection(String drop, String from , String to , String date) {
//        home = new HomePage(driver);
//        home.setFrom(from);
//        home.setTo(to);
//        home.setDate(date);
//        home.clickButton();
//        planeSelectionPage = new PlaneSelectionPage(driver);
//        planeSelectionPage.setSelectButton();
//        planeSelectionPage.setContinueButton();
//        planeSelectionPage.validate();
//    }

    @Test(dataProvider = "guestDataMethod", priority = 3)
    public void guestDetails(String fName, String lName, String age, String gender, String passport) {
        home = new HomePage(driver);
        home.setFrom("GOI");
        home.setTo("SIN");
        home.setDate("08-06-2026");
        home.clickButton();
        planeSelectionPage = new PlaneSelectionPage(driver);
        planeSelectionPage.clickButton();
        planeSelectionPage.setSelectButton();
        planeSelectionPage.setContinueButton();
        planeSelectionPage.validate();
        guestDetailsPage = new GuestDetailsPage(driver);
        guestDetailsPage.setFirstName(fName);
        guestDetailsPage.setLastName(lName);
        guestDetailsPage.setAge(age);
        guestDetailsPage.setGender(gender);
        guestDetailsPage.setPassportNumber(passport);
        guestDetailsPage.clickSubmit();
        guestDetailsPage.clickConfirm();
    }

    // Search with same origin and destination
    @Test(priority = 4)
    public void searchWithSameFromAndTo() {
        home = new HomePage(driver);
        home.setFrom("COK");
        home.setTo("COK");
        home.setDate("05-06-2026");
        home.clickButton();
        Assert.assertTrue(driver.getCurrentUrl().contains("/home"),
                "Same origin and destination should not proceed");
    }

    // Search with empty from field
    @Test(priority = 5)
    public void searchWithEmptyFrom() {
        home = new HomePage(driver);
        home.setTo("BLR");
        home.setDate("05-06-2026");
        home.clickButton();
        Assert.assertTrue(driver.getCurrentUrl().contains("/home"),
                "Empty from field should not proceed");
    }
    @Test(priority = 6)
    public void searchWithEmptyTo() {
        home = new HomePage(driver);
        home.setFrom("COK");
        home.setDate("05-06-2026");
        home.clickButton();
        Assert.assertTrue(driver.getCurrentUrl().contains("/home"),
                "Empty to field should not proceed");
    }

    // Search with no date
    @Test(priority = 7)
    public void searchWithEmptyDate() {
        home = new HomePage(driver);
        home.setFrom("COK");
        home.setTo("BLR");
        home.clickButton(); // no date set
        Assert.assertTrue(driver.getCurrentUrl().contains("/home"),
                "Empty date should not proceed");
    }

    @Test(priority = 8)
    public void navigateToFlightStatus() throws InterruptedException {
        home = new HomePage(driver);
        home.setFlightStatusPage();
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.urlContains("/flight-status"));
        Assert.assertTrue(driver.getCurrentUrl().contains("/flight-status"),
                "Should navigate to flight status page");
    }

    // Navigate to My Booking page
    @Test(priority = 9)
    public void navigateToMyBooking() {
        home = new HomePage(driver);
        home.setMyBookingPage();
        Assert.assertTrue(driver.getCurrentUrl().contains("/my-booking"),
                "Should navigate to my booking page");
    }

    @Test(priority = 10)
    public void tatkalBookingFlow() {
        home = new HomePage(driver);
        home.setFrom("COK");
        home.setTo("BLR");
        home.setDate("30-05-2026");
        home.setTatkalElement();
        Assert.assertTrue(driver.getCurrentUrl().contains("/booking"),
                "Tatkal should proceed to booking");
    }
}
