package org.example.Tests.UserTest;

import net.bytebuddy.build.Plugin;
import org.example.Listeners.TestListener;
import org.example.Pages.UserPages.LoginPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.time.Duration;

@Listeners(TestListener.class)
public class LoginTests extends BaseTest {

    private static final String validUser = "vignesh@gmail.com";
    private static final String validPass = "Vignesh@1234";
    private static final String wrongUser = "nobody@deccan.com";
    private static final String wrongPass  = "nobodyDeccan@6789";

    @BeforeMethod
    public void checker() {
        if(driver.getCurrentUrl().contains("/login")) {
            return;
        }
        driver.findElement(By.xpath("//button[@class='nav-logout']")).click();
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.visibilityOfElementLocated(
                        By.xpath("//input[@formcontrolname='email']")
                ));
    }

    @Test(priority = 1)
    public void testValidUser(){

        LoginPage loginPage = new LoginPage(driver);
        loginPage.setUsername(validUser);
        loginPage.setPassword(validPass);
        loginPage.clickButton();
        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(4));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'WELCOME')]")));

        String linktext = driver.getCurrentUrl();
        Assert.assertEquals(linktext,"http://localhost:4200/home");
    }

    @Test(priority = 2)
    public void testInvalidPassword() {
        // valid username, wrong password
        // Assert: error message like "Invalid credentials" is shown
        // Assert: URL is still /login
        LoginPage loginPage = new LoginPage(driver);
        loginPage.setUsername(validUser);
        loginPage.setPassword(wrongPass);
        loginPage.clickButton();
        String linktext = driver.getCurrentUrl();
        Assert.assertEquals(linktext,"http://localhost:4200/login");
    }

    @Test(priority = 3)
    public void testInvalidUsername() {
        // wrong username, valid password
        // Assert: error message shown
        // Assert: URL stays at /login
        LoginPage loginPage = new LoginPage(driver);
        loginPage.setUsername(wrongUser);
        loginPage.setPassword(validPass);
        loginPage.clickButton();
        String linktext = driver.getCurrentUrl();
        Assert.assertEquals(linktext,"http://localhost:4200/login");
    }

    @Test(priority = 4)
    public void testBothInvalid() {
        // wrong username + wrong password
        // Assert: error message shown
        LoginPage loginPage = new LoginPage(driver);
        loginPage.setUsername(wrongUser);
        loginPage.setPassword(wrongPass);
        loginPage.clickButton();
        String linktext = driver.getCurrentUrl();
        Assert.assertEquals(linktext,"http://localhost:4200/login");
    }

    @Test(priority = 5)
    public void testEmptyUsername() {
        // leave username blank, enter password, click submit
        // Assert: validation message appears on username field
        LoginPage loginPage = new LoginPage(driver);
        loginPage.setUsername("");
        loginPage.setPassword(validPass);
        loginPage.clickButton();
        String linktext = driver.getCurrentUrl();
        Assert.assertEquals(linktext,"http://localhost:4200/login");
    }

    @Test(priority = 6)
    public void testEmptyPassword() {
        // enter username, leave password blank, click submit
        // Assert: validation message appears on password field
        LoginPage loginPage = new LoginPage(driver);
        loginPage.setUsername(validUser);
        loginPage.setPassword("");
        loginPage.clickButton();
        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(4));
        String linktext = driver.getCurrentUrl();
        Assert.assertEquals(linktext,"http://localhost:4200/login");
    }

    @Test(priority = 7)
    public void testBothEmpty() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.setUsername("");
        loginPage.setPassword("");
        loginPage.clickButton();
        String linktext = driver.getCurrentUrl();
        Assert.assertEquals(linktext,"http://localhost:4200/login");
    }
}
