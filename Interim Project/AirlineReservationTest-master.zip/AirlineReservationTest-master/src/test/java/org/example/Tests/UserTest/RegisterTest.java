package org.example.Tests.UserTest;

import org.example.Listeners.TestListener;
import org.example.Pages.UserPages.RegisterPage;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.time.Duration;

@Listeners(TestListener.class)
public class RegisterTest extends BaseTest {

    RegisterPage registerPage;

    @BeforeMethod
    public void navigateToRegister() {
        driver.get("http://localhost:4200/register");
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.visibilityOfElementLocated(
                        By.xpath("//button[@class='register-button']")));
        registerPage = new RegisterPage(driver);
    }

    @DataProvider(name = "validRegisterData")
    public Object[][] validRegisterData() {
        return new Object[][]{
                {"Virat", "Kohli", "virat@gmail.com", "9876543210", "Virat@1234", "Virat@1234"}
        };
    }

    @DataProvider(name = "invalidEmailData")
    public Object[][] invalidEmailData() {
        return new Object[][]{
                {"Virat", "Kohli", "notanemail",    "9876543210", "Virat@1234", "Virat@1234"},
                {"Virat", "Kohli", "missing@",      "9876543210", "Virat@1234", "Virat@1234"},
                {"Virat", "Kohli", "@nodomain.com", "9876543210", "Virat@1234", "Virat@1234"},
        };
    }

    // Valid registration — should navigate away from /register
    @Test(dataProvider = "validRegisterData")
    public void validRegistrationShouldSucceed(String fn, String ln, String mail,
                                               String ph, String pass, String confirmPass) {
        registerPage.register(fn, ln, mail, ph, pass, confirmPass);
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.not(
                        ExpectedConditions.urlContains("/register")));
        Assert.assertFalse(driver.getCurrentUrl().contains("/register"),
                "Successful registration should navigate away from register page");
    }

    // Empty form — should not submit
    @Test
    public void emptyFormShouldNotSubmit() {
        registerPage.clickRegister();
        Assert.assertTrue(driver.getCurrentUrl().contains("/register"),
                "Empty form should not navigate away");
    }

    // Missing first name
    @Test
    public void missingFirstNameShouldNotSubmit() {
        registerPage.setLastName("Kohli");
        registerPage.setEmail("virat@gmail.com");
        registerPage.setPhone("9876543210");
        registerPage.setPassword("Virat@1234");
        registerPage.setConfirmPassword("Virat@1234");
        registerPage.checkAgreeTerms();
        registerPage.clickRegister();
        Assert.assertTrue(driver.getCurrentUrl().contains("/register"),
                "Missing first name should not submit");
    }

    // Missing last name
    @Test
    public void missingLastNameShouldNotSubmit() {
        registerPage.setFirstName("Virat");
        registerPage.setEmail("virat@gmail.com");
        registerPage.setPhone("8789062515");
        registerPage.setPassword("Virat@1234");
        registerPage.setConfirmPassword("Virat@1234");
        registerPage.checkAgreeTerms();
        registerPage.clickRegister();
        Assert.assertTrue(driver.getCurrentUrl().contains("/register"),
                "Missing last name should not submit");
    }

    // Invalid email formats
    @Test(dataProvider = "invalidEmailData")
    public void invalidEmailShouldNotSubmit(String fn, String ln, String mail,
                                            String ph, String pass, String confirmPass) {
        registerPage.register(fn, ln, mail, ph, pass, confirmPass);
        Assert.assertTrue(driver.getCurrentUrl().contains("/register"),
                "Invalid email should not submit: " + mail);
    }

    // Password and confirm password mismatch
    @Test
    public void passwordMismatchShouldNotSubmit() {
        registerPage.setFirstName("Virat");
        registerPage.setLastName("Kohli");
        registerPage.setEmail("virat@gmail.com");
        registerPage.setPhone("9876543210");
        registerPage.setPassword("Virat@1234");
        registerPage.setConfirmPassword("WrongPass@999");
        registerPage.checkAgreeTerms();
        registerPage.clickRegister();
        Assert.assertTrue(driver.getCurrentUrl().contains("/register"),
                "Password mismatch should not submit");
    }

    // Phone number less than 10 digits
    @Test
    public void shortPhoneNumberShouldNotSubmit() {
        registerPage.setFirstName("Virat");
        registerPage.setLastName("Kohli");
        registerPage.setEmail("virat@gmail.com");
        registerPage.setPhone("12345");
        registerPage.setPassword("Virat@1234");
        registerPage.setConfirmPassword("Virat@1234");
        registerPage.checkAgreeTerms();
        registerPage.clickRegister();
        Assert.assertTrue(driver.getCurrentUrl().contains("/register"),
                "Short phone number should not submit");
    }

    // Terms not checked — should not submit
    @Test
    public void uncheckedTermsShouldNotSubmit() {
        registerPage.setFirstName("Virat");
        registerPage.setLastName("Kohli");
        registerPage.setEmail("virat@gmail.com");
        registerPage.setPhone("9876543210");
        registerPage.setPassword("Virat@1234");
        registerPage.setConfirmPassword("Virat@1234");
        registerPage.clickRegister();
        Assert.assertTrue(driver.getCurrentUrl().contains("/register"),
                "Unchecked terms should not submit");
    }

    // Show password toggle should change input type
    @Test
    public void showPasswordToggleShouldWork() {
        registerPage.setPassword("Virat@1234");
        Assert.assertFalse(registerPage.isPasswordVisible(),
                "Password should be hidden by default");
        registerPage.clickShowPassword();
        Assert.assertTrue(registerPage.isPasswordVisible(),
                "Password should be visible after clicking Show");
    }

    // Login link should navigate to login page
    @Test
    public void loginLinkShouldNavigateToLogin() {
        registerPage.clickLoginLink();
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.urlContains("/login"));
        Assert.assertTrue(driver.getCurrentUrl().contains("/login"),
                "Login link should navigate to login page");
    }

    // Duplicate email — should show error
    @Test
    public void duplicateEmailShouldShowError() {
        // Use an email that already exists in the system
        registerPage.register(
                "Virat", "Kohli",
                "vignesh@gmail.com",
                "9876543210", "Virat@1234", "Virat@1234"
        );
        Assert.assertTrue(driver.getCurrentUrl().contains("/register"),
                "Duplicate email should stay on register page");
    }

    // Weak password — should not submit
    @Test
    public void weakPasswordShouldNotSubmit() {
        registerPage.setFirstName("Virat");
        registerPage.setLastName("Kohli");
        registerPage.setEmail("virat@gmail.com");
        registerPage.setPhone("9876543210");
        registerPage.setPassword("1234");
        registerPage.setConfirmPassword("1234");
        registerPage.checkAgreeTerms();
        registerPage.clickRegister();
        Assert.assertTrue(driver.getCurrentUrl().contains("/register"),
                "Weak password should not submit");
    }
}