package org.example.Tests.AdminTest;

import org.example.Pages.AdminPages.AdminBooking;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.List;


public class AdminBookingTest extends AdminBaseTest {

    AdminBooking adminBooking;

    String flightCode = "DA 234";

    @BeforeMethod
    public void navigator() {
        driver.get("http://localhost:4200/admin/flights");
    }

    @Test(priority = 1)
    public void bookingValidation(){
        adminBooking = new AdminBooking(driver);
        adminBooking.setNavElement();
        adminBooking.setViewPassengersClick();
        adminBooking.setBookingCheck();
    }

    @Test(priority = 2)
    public void filterBookingByFlightCode() throws InterruptedException {
        adminBooking = new AdminBooking(driver);
        adminBooking.setSearchName(flightCode);
        boolean status = adminBooking.getElements();
        Assert.assertTrue(status);
    }

}
