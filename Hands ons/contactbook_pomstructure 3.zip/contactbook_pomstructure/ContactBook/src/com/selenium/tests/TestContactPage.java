package com.selenium.tests;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.selenium.setup.DriverSetup;
import com.selenium.setup.XMLUtils;
import com.selenium.pages.ContactPageValues;
import org.testng.annotations.Listeners;

@Listeners(FeatureTest.class)  //Do not change or remove this line.
public class TestContactPage extends DriverSetup {

    public static WebDriver driver;
    public static ContactPageValues addressObj;
    private static String validResult;

    private String baseUrl = "https://webapps.tekstac.com/AddressBook/";

    public static String getValidResult() {
		return validResult;
	}

	public static void setValidResult(String validResult) {
		TestContactPage.validResult = validResult;
	}

    @BeforeClass
    public WebDriver setUp() {
        // Create the driver using getDriver() from DriverSetup
        driver = DriverSetup.getDriver();
        // Navigate to the baseUrl
        driver.get(baseUrl);

		//DO NO CHANGE THE BELOW OBJECT CREATION LINE
        addressObj = new ContactPageValues(driver);
        return driver;
    }

    public static String[] getXMLData(String fileName) throws Exception {

	    // Call readFile in XMLUtils with the passed filename and return its array
	    return XMLUtils.readFile(fileName);
	}


    @Test
	public void testValidSubmittedDetails() throws Exception{

    	// Call getXMLData() to read the XML file 'address.xml'
    	String[] data = getXMLData("address.xml");

    	// Set values using addressObj's setter methods, passing values read from XML data
    	addressObj.setNickName(data[0]);
    	addressObj.setContactName(data[1]);
    	addressObj.setCompany(data[2]);
    	addressObj.setCity(data[3]);
    	addressObj.setCountry(data[4]);
    	addressObj.setType(data[5]);

    	// Submit the form
    	addressObj.clickAddButton();

    	// Get the contact name displayed in the result and set as validResult
    	validResult = addressObj.getContactName();
    	setValidResult(validResult);
    }


    @AfterClass
	public void closeBrowser() {
		// Close the driver
		if (driver != null) {
			driver.close();
		}
	}
}
