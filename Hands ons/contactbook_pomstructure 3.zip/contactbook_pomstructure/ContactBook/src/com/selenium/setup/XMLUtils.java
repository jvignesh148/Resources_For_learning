package com.selenium.setup;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class XMLUtils {      //Do not change the class name

    static String[] xmlData;

	public static String[] readFile(String fileName) throws Exception { // Do not change the method signature

		// Parse the XML file
		File xmlFile = new File(fileName);
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document doc = builder.parse(xmlFile);
		doc.getDocumentElement().normalize();

		// Get the first <Service> element
		NodeList serviceList = doc.getElementsByTagName("Service");
		Element serviceElement = (Element) serviceList.item(0);

		// Read the 6 fields in order and populate xmlData
		xmlData = new String[6];
		xmlData[0] = serviceElement.getElementsByTagName("NickName").item(0).getTextContent();
		xmlData[1] = serviceElement.getElementsByTagName("ContactName").item(0).getTextContent();
		xmlData[2] = serviceElement.getElementsByTagName("Company").item(0).getTextContent();
		xmlData[3] = serviceElement.getElementsByTagName("City").item(0).getTextContent();
		xmlData[4] = serviceElement.getElementsByTagName("Country").item(0).getTextContent();
		xmlData[5] = serviceElement.getElementsByTagName("Type").item(0).getTextContent();

		return xmlData;
	}

}
