package com.selenium.pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Dimension;

public class ContactPageValues { // DO NOT CHANGE THE CLASS NAME

	// Use the below declared variable
	private WebDriver driver;
	private WebElement element;


    //Constructors are already given. If required, you can add more code into it but do NOT remove the existing code.
    public ContactPageValues(){}

	public ContactPageValues(WebDriver driver){
		this.driver= driver;
	}

	// Implement code here

	public void setNickName(String nickName) {
		driver.findElement(By.id("nickname")).sendKeys(nickName);
	}

	public void setContactName(String contact) {
		driver.findElement(By.id("contact")).sendKeys(contact);
	}

	public void setCompany(String company) {
		driver.findElement(By.id("company")).sendKeys(company);
	}

	public void setCity(String city) {
		driver.findElement(By.id("city")).sendKeys(city);
	}

	public void setCountry(String country) {
		driver.findElement(By.id("country")).sendKeys(country);
	}

	public void setType(String type) {
		driver.findElement(By.id("type")).sendKeys(type);
	}

	public void clickAddButton() {
		driver.findElement(By.id("add")).click();
	}


	// Result is displayed in <div id="result"> as a table.
	// Row 1 = header (<th>), Row 2 = data (<td>) with values in 6 columns

	public String getNickName() {
		element = driver.findElement(By.xpath("//div[@id='result']//tr[2]/td[1]"));
		return element.getText();
	}

	public String getContactName() {
		element = driver.findElement(By.xpath("//div[@id='result']//tr[2]/td[2]"));
		return element.getText();
	}

	public String getCompany() {
		element = driver.findElement(By.xpath("//div[@id='result']//tr[2]/td[3]"));
		return element.getText();
	}

	public String getCity() {
		element = driver.findElement(By.xpath("//div[@id='result']//tr[2]/td[4]"));
		return element.getText();
	}

	public String getCountry() {
		element = driver.findElement(By.xpath("//div[@id='result']//tr[2]/td[5]"));
		return element.getText();
	}

	public String getType() {
		element = driver.findElement(By.xpath("//div[@id='result']//tr[2]/td[6]"));
		return element.getText();
	}

}
