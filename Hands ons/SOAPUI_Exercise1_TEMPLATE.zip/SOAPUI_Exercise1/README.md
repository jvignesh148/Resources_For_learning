# SoapUI Exercise 1 — Web Services Project Using WSDL

## 1. Objective

Create a web services project in SoapUI using a public WSDL, identify the
endpoint, construct input/output XML, validate the response against the
WSDL, and modify the WSDL to reinforce understanding of its structure.

## 2. WSDL Chosen

**CountryInfoService** — a free, public SOAP service that returns country
information by ISO code. No authentication required.

WSDL URL:
```
http://webservices.oorsprong.org/websamples.countryinfo/CountryInfoService.wso?wsdl
```

| Property      | Value                                                                       |
|---------------|-----------------------------------------------------------------------------|
| Service Name  | CountryInfoService                                                          |
| Endpoint      | http://webservices.oorsprong.org/websamples.countryinfo/CountryInfoService.wso |
| Binding Style | Document / Literal                                                          |
| Transport     | HTTP                                                                        |
| Namespace     | http://www.oorsprong.org/websamples.countryinfo                              |

## 3. Steps Performed in SoapUI

1. Launched SoapUI Open Source desktop application.
2. File → **New SOAP Project**.
3. Entered project name `CountryInfoService_Project` and the WSDL URL above.
4. Checked "Create Requests" and "Create TestSuite", clicked **OK**.
5. SoapUI parsed the WSDL and generated all operations with sample request XMLs.
6. Chose to generate a TestSuite with **one TestCase per operation** and
   **Create new Requests** option.
7. Identified the endpoint from the service viewer (above).
8. Configured input XML for three operations and ran each request.
9. Added a **Schema Compliance** assertion to each request to validate
   the response against the WSDL.
10. Ran the entire TestSuite — all enabled TestCases passed.
11. Saved the project as `CountryInfoService_Project-soapui-project.xml`.

## 4. Operations Tested

### 4.1 CapitalCity
- **Input:**  `sCountryISOCode = IN`
- **Output:** `New Delhi`
- Files: `RequestResponse_XML/CapitalCity_Request.xml`, `CapitalCity_Response.xml`

### 4.2 CountryName
- **Input:**  `sCountryISOCode = US`
- **Output:** `United States`
- Files: `RequestResponse_XML/CountryName_Request.xml`, `CountryName_Response.xml`

### 4.3 FullCountryInfo (complex response)
- **Input:**  `sCountryISOCode = IN`
- **Output:** Complex object containing ISO code, name, capital, phone code,
  continent, currency, flag URL, and a list of languages.
- Files: `RequestResponse_XML/FullCountryInfo_Request.xml`, `FullCountryInfo_Response.xml`

## 5. Validation Against WSDL

| WSDL Element                       | Defined Type      | Actual Response        | Match |
|------------------------------------|-------------------|------------------------|-------|
| CapitalCityResult                  | xsd:string        | "New Delhi"            | ✅    |
| CountryNameResult                  | xsd:string        | "United States"        | ✅    |
| FullCountryInfoResult              | tCountryInfo      | Complex element        | ✅    |
| FullCountryInfoResult/sISOCode     | xsd:string        | "IN"                   | ✅    |
| FullCountryInfoResult/sPhoneCode   | xsd:string        | "91"                   | ✅    |
| FullCountryInfoResult/Languages    | array of tLanguage| Hindi, English entries | ✅    |

**Validation method:** In SoapUI, the **Schema Compliance** assertion
(under Compliance, Status and Standards) was added to each TestStep.
All three assertions returned **VALID**, confirming that the responses
conform to the WSDL schema. See `Screenshots/06_SchemaCompliance_Pass.png`
and `Screenshots/07_TestSuite_AllPassed.png`.

## 6. WSDL Modifications (Step 4 of Exercise)

The modified WSDL is at `WSDL/CountryInfoService_Modified.wsdl`.

| # | Change                  | Original                                           | Modified                                                          |
|---|-------------------------|----------------------------------------------------|-------------------------------------------------------------------|
| 1 | Service name            | `CountryInfoService`                               | `CountryInfoService_Practice`                                     |
| 2 | Binding style           | `style="document"` with `use="literal"`            | `style="rpc"` with `use="encoded"` + `encodingStyle` attribute    |
| 3 | minOccurs / maxOccurs   | Implicit (default 1/1) on `sCountryISOCode`        | Explicitly set to `minOccurs="1" maxOccurs="1"`                   |
| 4 | maxOccurs="unbounded"   | `Languages` declared as single element             | `Languages` declared with `minOccurs="0" maxOccurs="unbounded"`   |

### What each change demonstrates

- **Service rename** — shows how the WSDL `<service>` element controls the
  human-readable service identifier without affecting the endpoint URL.
- **Document → RPC style** — illustrates the two SOAP messaging styles.
  Document/Literal wraps the payload in a single XML element matching the
  schema; RPC/Encoded names the operation in the SOAP body and encodes
  parameters per SOAP encoding rules.
- **minOccurs / maxOccurs** — clarifies element cardinality. `minOccurs="0"`
  would make a field optional; `maxOccurs="unbounded"` allows lists/repetition.

## 7. Folder Structure

```
SOAPUI_Exercise1/
├── README.md                                          (this file)
├── CountryInfoService_Project-soapui-project.xml      SoapUI project file
├── WSDL/
│   └── CountryInfoService_Modified.wsdl               WSDL with 4 modifications
├── RequestResponse_XML/
│   ├── CapitalCity_Request.xml
│   ├── CapitalCity_Response.xml
│   ├── CountryName_Request.xml
│   ├── CountryName_Response.xml
│   ├── FullCountryInfo_Request.xml
│   └── FullCountryInfo_Response.xml
└── Screenshots/
    ├── 01_NewProject_Dialog.png
    ├── 02_Project_Tree.png
    ├── 03_CapitalCity_Request_Response.png
    ├── 04_CountryName_Request_Response.png
    ├── 05_FullCountryInfo_Response.png
    ├── 06_SchemaCompliance_Pass.png
    └── 07_TestSuite_AllPassed.png
```

## 8. How to Reproduce

1. Install SoapUI Open Source.
2. File → New SOAP Project → paste the WSDL URL listed in Section 2.
3. Tick "Create Requests" and "Create TestSuite" → OK.
4. In the TestSuite generator dialog, choose "One TestCase for each
   Operation" and "Create new Requests" → OK.
5. For each operation (CapitalCity, CountryName, FullCountryInfo):
   - Open the TestStep, replace `?` with a valid ISO code, click ▶.
   - In the Assertions tab, add **Schema Compliance** assertion.
6. Right-click the TestSuite → Run, verify all green.
7. To inspect the modified WSDL: File → New SOAP Project → Browse to
   `WSDL/CountryInfoService_Modified.wsdl`. Confirm the renamed service
   appears in the navigator.

## 9. Conclusion

The exercise demonstrates the end-to-end SOAP testing workflow:
- Importing a WSDL into SoapUI
- Discovering the service endpoint
- Constructing valid input XML matching the WSDL schema
- Submitting requests and receiving responses
- Validating responses against the WSDL using Schema Compliance assertions
- Modifying a WSDL to understand the relationship between schema constructs
  (service name, binding style, cardinality) and the resulting messages.
