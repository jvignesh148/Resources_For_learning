# SoapUI Exercise 2 — REST Web Services Project Using WADL

## 1. Objective

Create a REST web services project in SoapUI using a WADL (Web Application
Description Language) file, identify endpoints, construct request/response
data, validate the output, and modify the WADL to reinforce understanding of
its structure.

## 2. API Chosen

**JSONPlaceholder** — a free, reliable public REST API for testing.

```
Base URL: https://jsonplaceholder.typicode.com
```

> Note: The URL listed in the original exercise statement
> (`http://zero.webappsecurity.com/web-services/secureInfoService?wsdl`) is
> a SOAP WSDL endpoint and the host is intermittently unreachable.
> JSONPlaceholder is used instead because it is a genuine REST service
> ideal for WADL practice.

| Property      | Value                                                |
|---------------|------------------------------------------------------|
| Style         | REST                                                 |
| Base URL      | https://jsonplaceholder.typicode.com                 |
| Default Type  | application/json                                     |
| Auth required | No                                                   |

## 3. WADL File

The WADL describing the API is in `WADL/JSONPlaceholder_Original.wadl`.
A modified version is in `WADL/JSONPlaceholder_Modified.wadl`.

The WADL defines:
- Base URL (`<resources base="...">`)
- Resources (e.g. `/posts`, `/posts/{id}`, `/users`, `/users/{id}`)
- Methods on each resource (GET, POST, etc.)
- Request/response media types (`application/json`, `application/xml`)
- Path parameters (e.g. `id`)

## 4. Steps Performed in SoapUI

1. Launched SoapUI Open Source.
2. **File → New REST Project**.
3. Entered the URI `https://jsonplaceholder.typicode.com/posts/1` → OK.
4. SoapUI created a REST project, service, resource, and request.
5. Added two more resources by right-clicking the service node:
   - `/users/{id}` with a GET method
   - `/posts` with a POST method
6. Ran each request, viewed the JSON response, and added assertions.

## 5. Endpoints Tested

### 5.1 GET /posts/{id}
- **Endpoint:** `https://jsonplaceholder.typicode.com/posts/1`
- **Method:**   GET
- **Input:**    Path parameter `id = 1`
- **Output:**   JSON object with `userId`, `id`, `title`, `body`
- **Status:**   200 OK
- Files: `RequestResponse/01_GetPostById_Request.txt`,
         `RequestResponse/02_GetPostById_Response.json`

### 5.2 GET /users/{id}
- **Endpoint:** `https://jsonplaceholder.typicode.com/users/2`
- **Method:**   GET
- **Input:**    Path parameter `id = 2`
- **Output:**   JSON object with user details (name, email, address, company)
- **Status:**   200 OK
- Files: `RequestResponse/03_GetUserById_Request.txt`,
         `RequestResponse/04_GetUserById_Response.json`

### 5.3 POST /posts
- **Endpoint:** `https://jsonplaceholder.typicode.com/posts`
- **Method:**   POST
- **Input:**    JSON body `{ "userId": 1, "title": "...", "body": "..." }`
- **Output:**   Created post with new `id` (e.g. 101)
- **Status:**   201 Created
- Files: `RequestResponse/05_CreatePost_Request.txt`,
         `RequestResponse/06_CreatePost_Response.json`

## 6. Validation

Assertions added in SoapUI on each request (Assertions tab → Add Assertion):

| Assertion Type             | Configuration                       | Result |
|----------------------------|-------------------------------------|--------|
| Valid HTTP Status Codes    | 200, 201                            | ✅ VALID |
| JSONPath Match             | `$.id` = 1 (for GET /posts/1)       | ✅ VALID |
| JSONPath Match             | `$.userId` = 1                      | ✅ VALID |
| JSONPath Match             | `$.id` = 2 (for GET /users/2)       | ✅ VALID |
| JSONPath Match             | `$.name` = "Ervin Howell"           | ✅ VALID |
| Response SLA               | < 1000 ms                           | ✅ VALID |

These assertions verify that the response conforms to the structure
declared in the WADL (JSON object with the expected fields and types).

## 7. WADL Modifications (Step 4 of Exercise)

The modified WADL is at `WADL/JSONPlaceholder_Modified.wadl`.

| # | Change                                  | Original                                | Modified                                          |
|---|-----------------------------------------|-----------------------------------------|---------------------------------------------------|
| 1 | Application title                       | "JSONPlaceholder REST API"              | "JSONPlaceholder REST API (Practice)"             |
| 2 | **Response media type (key change)**    | `application/json` for getPostById      | `application/xml` for getPostById                 |
| 3 | POST request representations            | Only `application/json`                 | Both `application/json` AND `application/xml`     |
| 4 | Added documentation                     | No `<doc>` on getPostById               | `<doc title="Get Post By ID">...</doc>` added     |

### Key Change Explained

**Modification 2** is the change the exercise explicitly asks for:
*"convert response output from XML to JSON or vice-versa"*.

In the modified WADL, the `getPostById` operation now declares that its
response is `application/xml` instead of `application/json`. This shows
how the WADL contract controls the expected response format. In a real
REST API that supports both formats, clients would set the
`Accept: application/xml` header to receive XML, and `Accept: application/json`
for JSON. JSONPlaceholder itself only returns JSON, but the WADL has been
updated to demonstrate the concept.

## 8. Folder Structure

```
SOAPUI_Exercise2/
├── README.md                                         (this file)
├── WADL/
│   ├── JSONPlaceholder_Original.wadl                 Original WADL
│   └── JSONPlaceholder_Modified.wadl                 With 4 modifications
├── RequestResponse/
│   ├── 01_GetPostById_Request.txt
│   ├── 02_GetPostById_Response.json
│   ├── 03_GetUserById_Request.txt
│   ├── 04_GetUserById_Response.json
│   ├── 05_CreatePost_Request.txt
│   └── 06_CreatePost_Response.json
└── Screenshots/
    ├── 01_NewRESTProject_Dialog.png
    ├── 02_GET_Posts_Response.png
    ├── 03_GET_Users_Response.png
    ├── 04_POST_Posts_Response.png
    ├── 05_JSONPath_Assertions_Pass.png
    └── 06_Modified_WADL.png
```

## 9. How to Reproduce

1. Install SoapUI Open Source.
2. **File → New REST Project**.
3. URI: `https://jsonplaceholder.typicode.com/posts/1` → OK.
4. Run the auto-generated GET request → confirm JSON response.
5. Add resources `/users/{id}` and `/posts` (with POST).
6. For POST, in the request body set Media Type `application/json` and
   provide a JSON body.
7. For each request, in Assertions tab add:
   - Valid HTTP Status Codes (200, 201)
   - JSONPath Match assertions on key fields
8. Save the project as `JSONPlaceholder_Project-soapui-project.xml`.
9. Optionally: **File → Import WADL** and pick `JSONPlaceholder_Modified.wadl`
   to see SoapUI parse the modified definition.

## 10. Conclusion

This exercise demonstrates the REST testing workflow with SoapUI using
WADL:
- Importing/working with a WADL to describe REST resources
- Discovering endpoints and methods
- Constructing GET/POST requests with path parameters and JSON bodies
- Validating responses with JSONPath and HTTP status assertions
- Modifying a WADL to change response media types and add new
  representation options — demonstrating the JSON ↔ XML conversion
  concept the exercise highlights.
