Feature: Basic Contact Form Submission

  Scenario Outline: Submit the basic contact form with valid details
    Given user opens the basic contact form page
    When user enters the name "<Name>" and email "<Email>"
    When user enters the message and submits the form
    Then the contact form should be submitted successfully

    Examples:
      | Name     | Email                |
      | John Doe | john.doe@example.com |
