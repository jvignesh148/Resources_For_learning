# ContactForm Cucumber Test Project (Scenario Outline)

## Overview
Cucumber BDD test project for the Basic Contact Form at
https://www.mycontactform.com/samples/basiccontact.php

Uses **Scenario Outline + Examples** to pass Name and Email.
Message is entered via sendKeys (not from Examples).

## Project Structure
```
ContactFormCucumberOutline/
├── pom.xml
└── src/test/
    ├── java/
    │   ├── hooks/Hooks.java                   (@Before / @After)
    │   ├── runner/TestRunner.java
    │   └── stepDefinitions/ContactFormStepDefinitions.java
    └── resources/features/ContactForm.feature
```

## Form Field Mapping
- **Name**: `name="q[1]"`
- **Email**: `id="email"`
- **Message**: `name="q[2]"` (sendKeys, not from outline)
- **Submit**: `name="submit"`

## IMPORTANT: ChromeDriver Setup
Before running, update the chromedriver path in `Hooks.java` line 18:
```java
System.setProperty("webdriver.chrome.driver", "C:\\drivers\\chromedriver.exe");
```
Make sure the file exists at that path.

## How to Run
```bash
mvn clean test
```
Or right-click `TestRunner.java` → Run as JUnit Test.
