package stepDefinitions;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import hooks.Hooks;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

public class ContactFormStepDefinitions {

    @Given("user opens the basic contact form page")
    public void user_opens_the_basic_contact_form_page() {
        Hooks.driver.get("https://www.mycontactform.com/samples/basiccontact.php");
        String title = Hooks.driver.getTitle();
        System.out.println("Page Title: " + title);
        Assert.assertTrue("Page did not load correctly", title.contains("Contact Form"));
    }

    @When("user enters the name and email details")
    public void user_enters_the_name_and_email_details(DataTable dataTable) {
        List<Map<String, String>> data = dataTable.asMaps(String.class, String.class);
        Map<String, String> row = data.get(0);

        String name = row.get("Name");
        String email = row.get("Email");

        // Name field has name="q[1]"
        WebElement nameField = Hooks.driver.findElement(By.name("q[1]"));
        nameField.clear();
        nameField.sendKeys(name);

        // Email field has id="email"
        WebElement emailField = Hooks.driver.findElement(By.id("email"));
        emailField.clear();
        emailField.sendKeys(email);

        // Validate values are entered correctly
        Assert.assertEquals("Name not entered correctly", name, nameField.getAttribute("value"));
        Assert.assertEquals("Email not entered correctly", email, emailField.getAttribute("value"));

        System.out.println("Name entered: " + name);
        System.out.println("Email entered: " + email);
    }

    @When("user enters the message and submits the form")
    public void user_enters_the_message_and_submits_the_form() {
        // Message field has name="q[2]" — entered via sendKeys (not from DataTable)
        WebElement messageField = Hooks.driver.findElement(By.name("q[2]"));
        messageField.clear();
        messageField.sendKeys("This is a test message submitted through Cucumber BDD automation.");
        System.out.println("Message entered via sendKeys");

        // Submit button has name="submit"
        WebElement submitButton = Hooks.driver.findElement(By.name("submit"));
        submitButton.click();
        System.out.println("Form submitted");
    }

    @Then("the contact form should be submitted successfully")
    public void the_contact_form_should_be_submitted_successfully() {
        // After submission the URL/page changes; verify navigation away from the original form
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        String currentUrl = Hooks.driver.getCurrentUrl();
        System.out.println("URL after submission: " + currentUrl);
        Assert.assertNotNull("URL is null after form submission", currentUrl);
        System.out.println("Contact form submission test completed successfully");
    }
}
