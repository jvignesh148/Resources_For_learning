Feature: Basic Contact Form Submission

  Scenario: Submit the basic contact form with valid details
    Given user opens the basic contact form page
    When user enters the name and email details
      | Name     | Email                |
      | John Doe | john.doe@example.com |
    When user enters the message and submits the form
    Then the contact form should be submitted successfully
