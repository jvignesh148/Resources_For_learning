# ContactForm Cucumber Test Project

## Overview
Cucumber BDD test project that validates the Basic Contact Form on
https://www.mycontactform.com/samples/basiccontact.php

## Project Structure
```
ContactFormCucumber/
├── pom.xml
└── src/
    └── test/
        ├── java/
        │   ├── hooks/
        │   │   └── Hooks.java               (@Before + @After lifecycle)
        │   ├── runner/
        │   │   └── TestRunner.java          (Cucumber JUnit runner)
        │   └── stepDefinitions/
        │       └── ContactFormStepDefinitions.java
        └── resources/
            └── features/
                └── ContactForm.feature      (Gherkin scenario with DataTable)
```

## What's Covered

1. **Feature file** with a valid registration scenario
2. **DataTable** passes only Name and Email
3. **Message** is entered via sendKeys (not from DataTable) - hardcoded in step definition
4. **@Before** instantiates Chrome browser; **@After** quits browser - in Hooks.java
5. **Runner file** (TestRunner.java) executes the tests

## Form Field Mapping
Based on the actual form HTML:
- **Name field**: `name="q[1]"` (text input)
- **Email field**: `id="email"` (text input)
- **Message field**: `name="q[2]"` (textarea)
- **Submit button**: `name="submit"` (input type="submit")

## Prerequisites
- Java 8 or higher
- Maven 3.x
- Chrome browser installed
- Internet connection

## How to Run

### Using Maven
```bash
mvn clean test
```

### Using IDE (Eclipse / IntelliJ)
1. Import as Maven project
2. Right-click on `TestRunner.java` → Run as JUnit Test

## Notes
- If `chromedriver` is not on system PATH, uncomment line 18 in Hooks.java:
  ```java
  System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
  ```
