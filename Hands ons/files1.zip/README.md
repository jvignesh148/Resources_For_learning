# Selenium + TestNG Hands-On — 14 Scenarios

A practice project covering core TestNG annotations, assertions, data-driven testing, parallel execution, retries, reporting, and annotation transformers.

## Setup

1. Install Java 11+ and Maven.
2. Selenium 4.6+ uses Selenium Manager — drivers download automatically. No need to set `webdriver.chrome.driver` manually.
3. From the project root, run `mvn test` to execute the full suite.

## Scenario → TestNG concept

| # | Scenario | Concepts taught |
|---|----------|-----------------|
| 1 | SwagLabs checkout | `@BeforeTest`, `@BeforeMethod`, `@Test`, `@AfterMethod`, `@AfterTest` lifecycle |
| 2 | Compound interest | Dropdowns (`Select`), text input, hard `Assert` |
| 3 | Verify title | `Assert.assertEquals` |
| 4 | Soft assertions | `SoftAssert` + `assertAll` (collects failures, doesn't stop) |
| 5 | BMI calculator | `@Test(priority = N)` controls execution order |
| 6 | OrangeHRM login/logout | `@Test(groups = {...})` and running groups via testng.xml |
| 7 | Bank deposit/withdraw | `@Test(dependsOnMethods = "...")` chains tests |
| 8 | Login with @Parameters | XML-driven inputs via `@Parameters` |
| 9 | Login with DataProvider | `@DataProvider` for code-driven multi-input testing |
| 10 | Parallel execution | `parallel="methods"` + `thread-count` in testng.xml |
| 11 | Retry failed test | `IRetryAnalyzer` to auto-rerun failures |
| 12 | Rerun failed-only | Use auto-generated `testng-failed.xml` |
| 13 | Log4j + reports | Logging integration; reports in `test-output/` |
| 14 | Annotation Transformer | `IAnnotationTransformer` to filter tests by name |

## Notes on locators

Web pages change — if a locator fails, right-click the element, Inspect, and update the `By.*` call. The locators here are accurate as of when this was written but are not guaranteed forever.

## Running individual scenarios

In IDE: right-click the class → Run as TestNG Test.

From Maven, edit `testng.xml` to include only the scenarios you want, then `mvn test`.

## Scenario 6 — groups

Edit `testng.xml` to include or exclude groups:

```xml
<test name="LoginOnly">
  <groups><run><include name="login"/></run></groups>
  <classes><class name="scenarios.Scenario06_OrangeHRMGroups"/></classes>
</test>
```

## Scenario 10 — parallel suite

```xml
<suite name="ParallelSuite" parallel="methods" thread-count="2">
  <test name="Parallel">
    <classes><class name="scenarios.Scenario10_ParallelExecution"/></classes>
  </test>
</suite>
```

## Scenario 12 — rerun failed

After a run, TestNG writes `test-output/testng-failed.xml`. Right-click it and Run as TestNG Suite to rerun only failed tests.

## Scenario 14 — annotation transformer

Register the listener in testng.xml; only methods ending in `middle` are enabled at runtime:

```xml
<listeners>
  <listener class-name="scenarios.Scenario14_AnnotationTransformer$MiddleOnlyTransformer"/>
</listeners>
```
