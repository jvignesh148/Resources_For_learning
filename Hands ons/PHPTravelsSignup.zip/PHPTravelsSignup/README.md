# PHPTravels Signup - Cucumber Test Project

## Overview
This is a Cucumber BDD test project that validates the signup form on phptravels.net.

## Project Structure
```
PHPTravelsSignup/
├── pom.xml
└── src/
    └── test/
        ├── java/
        │   ├── runner/
        │   │   └── TestRunner.java
        │   └── stepDefinitions/
        │       └── SignupStepDefinitions.java
        └── resources/
            └── features/
                └── Signup.feature
```

## Prerequisites
- Java 8 or higher
- Maven 3.x
- Chrome browser installed
- Internet connection

## How to Run

### Option 1: Using Maven
```bash
mvn clean test
```

### Option 2: Using IDE (Eclipse / IntelliJ)
1. Import as a Maven project
2. Right-click on `TestRunner.java` and run as JUnit test

## What it does
1. Opens https://www.phptravels.net/home
2. Clicks "My Account" and navigates to Sign Up page
3. Fills in form fields with values from DataTable:
   - First Name, Last Name, Mobile Number, Email, Password, Confirm Password
4. Validates that each field is populated correctly with the entered value

## Notes
- The project uses Selenium 3.141.59 with Cucumber 6.11.0
- ChromeDriver: if WebDriverManager is not used, set the chromedriver path manually in `SignupStepDefinitions.java`:
  ```java
  System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
  ```
- The XPath selectors are written defensively to handle multiple possible attribute combinations
