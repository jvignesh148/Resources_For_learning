Feature: PHPTravels Signup Page Validation

  Scenario: Validate signup form fields are displayed correctly
    Given user opens the PHPTravels home page
    When user clicks on My Account and selects Sign Up
    When user enters the signup details
      | FirstName | LastName | MobileNumber | Email             | Password   | ConfirmPassword |
      | John      | Doe      | 9876543210   | john.doe@test.com | Test@1234  | Test@1234       |
    Then signup form details should be validated successfully
