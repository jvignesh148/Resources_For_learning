package stepDefinitions;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

public class SignupStepDefinitions {

    WebDriver driver;
    WebDriverWait wait;

    @Given("user opens the PHPTravels home page")
    public void user_opens_the_PHPTravels_home_page() {
        // Set ChromeDriver path if needed:
        // System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        wait = new WebDriverWait(driver, 15);
        driver.get("https://www.phptravels.net/home");
    }

    @When("user clicks on My Account and selects Sign Up")
    public void user_clicks_on_My_Account_and_selects_Sign_Up() {
        try {
            // Try to click "My Account" link/button
            WebElement myAccount = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//*[contains(text(),'My Account') or contains(text(),'Account')]")));
            myAccount.click();
        } catch (Exception e) {
            // If My Account is a hover menu, navigate directly to signup
            driver.get("https://www.phptravels.net/signup");
        }

        // Click Sign Up link if present
        try {
            WebElement signUpLink = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//a[contains(text(),'Sign Up') or contains(@href,'signup')]")));
            signUpLink.click();
        } catch (Exception e) {
            // Already on signup page
            if (!driver.getCurrentUrl().contains("signup")) {
                driver.get("https://www.phptravels.net/signup");
            }
        }
    }

    @When("user enters the signup details")
    public void user_enters_the_signup_details(DataTable dataTable) {
        List<Map<String, String>> data = dataTable.asMaps(String.class, String.class);
        Map<String, String> row = data.get(0);

        String firstName = row.get("FirstName");
        String lastName = row.get("LastName");
        String mobileNumber = row.get("MobileNumber");
        String email = row.get("Email");
        String password = row.get("Password");
        String confirmPassword = row.get("ConfirmPassword");

        // Enter First Name
        WebElement firstNameField = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[@name='first_name' or @id='first_name' or @placeholder='First Name' or contains(@name,'firstname')]")));
        firstNameField.clear();
        firstNameField.sendKeys(firstName);

        // Enter Last Name
        WebElement lastNameField = driver.findElement(
                By.xpath("//input[@name='last_name' or @id='last_name' or @placeholder='Last Name' or contains(@name,'lastname')]"));
        lastNameField.clear();
        lastNameField.sendKeys(lastName);

        // Enter Mobile Number
        WebElement mobileField = driver.findElement(
                By.xpath("//input[@name='phone' or @name='mobile' or @id='mobile' or @id='phone' or @placeholder='Mobile Number']"));
        mobileField.clear();
        mobileField.sendKeys(mobileNumber);

        // Enter Email
        WebElement emailField = driver.findElement(
                By.xpath("//input[@type='email' or @name='email' or @id='email']"));
        emailField.clear();
        emailField.sendKeys(email);

        // Enter Password
        WebElement passwordField = driver.findElement(
                By.xpath("//input[@name='password' or @id='password']"));
        passwordField.clear();
        passwordField.sendKeys(password);

        // Enter Confirm Password
        WebElement confirmPasswordField = driver.findElement(
                By.xpath("//input[@name='confirm_password' or @id='confirm_password' or @name='confirmpassword' or contains(@placeholder,'Confirm')]"));
        confirmPasswordField.clear();
        confirmPasswordField.sendKeys(confirmPassword);

        // Validate values are populated
        Assert.assertEquals("First Name mismatch", firstName, firstNameField.getAttribute("value"));
        Assert.assertEquals("Last Name mismatch", lastName, lastNameField.getAttribute("value"));
        Assert.assertEquals("Mobile Number mismatch", mobileNumber, mobileField.getAttribute("value"));
        Assert.assertEquals("Email mismatch", email, emailField.getAttribute("value"));
        Assert.assertEquals("Password mismatch", password, passwordField.getAttribute("value"));
        Assert.assertEquals("Confirm Password mismatch", confirmPassword, confirmPasswordField.getAttribute("value"));

        System.out.println("All signup form fields are populated correctly:");
        System.out.println("First Name: " + firstName);
        System.out.println("Last Name: " + lastName);
        System.out.println("Mobile Number: " + mobileNumber);
        System.out.println("Email: " + email);
        System.out.println("Password: " + password);
        System.out.println("Confirm Password: " + confirmPassword);
    }

    @Then("signup form details should be validated successfully")
    public void signup_form_details_should_be_validated_successfully() {
        // Final validation - verify we're on signup page with all required fields visible
        String currentUrl = driver.getCurrentUrl();
        Assert.assertTrue("Not on signup page", currentUrl.contains("signup") || currentUrl.contains("account"));
        System.out.println("Signup form validation completed successfully on: " + currentUrl);
    }

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
